package android.app;

public class ActivityThread {
    public static Application currentApplication() {
        throw new RuntimeException("Stub!");
    }
}
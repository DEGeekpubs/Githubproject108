package android.os;

public class SELinux {

    public static native String getContext();
}
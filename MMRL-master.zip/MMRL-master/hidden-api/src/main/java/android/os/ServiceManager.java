package android.os;

public class ServiceManager {
    public static IBinder getService(String name) {
        throw new RuntimeException("Stub!");
    }
}
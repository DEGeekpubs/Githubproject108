package com.dergoogler.mmrl.ui.theme

import androidx.compose.material3.Shapes

val Shapes = Shapes()
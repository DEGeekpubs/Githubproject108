package com.dergoogler.mmrl.model.local

import dev.dergoogler.mmrl.compat.content.State

typealias State = State
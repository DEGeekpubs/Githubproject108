package com.dergoogler.mmrl.ui.utils

import androidx.compose.foundation.layout.WindowInsets

val WindowInsets.Companion.none get() = WindowInsets(0, 0, 0, 0)
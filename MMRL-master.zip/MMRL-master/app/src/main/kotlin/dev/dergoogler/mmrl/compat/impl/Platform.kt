package dev.dergoogler.mmrl.compat.impl

enum class Platform {
    Magisk,
    KernelSU,
    APatch
}
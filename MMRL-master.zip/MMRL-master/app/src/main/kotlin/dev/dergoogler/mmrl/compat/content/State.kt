package dev.dergoogler.mmrl.compat.content

enum class State {
    ENABLE,
    REMOVE,
    DISABLE,
    UPDATE
}